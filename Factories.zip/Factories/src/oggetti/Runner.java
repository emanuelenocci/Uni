package oggetti;

public class Runner {

	public static void main(String[] args) {
		Persona p1 = FactoryPersone.creaStudente("Luca", "Rossi", "RSILCA01P34DGJ");
	}
}
