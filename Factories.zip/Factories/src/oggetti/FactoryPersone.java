package oggetti;

public class FactoryPersone {
	
	public static Persona creaStudente(String nome, String cognome, String codiceFiscale) {
		return new Persona(nome, cognome, codiceFiscale);
	}
}
